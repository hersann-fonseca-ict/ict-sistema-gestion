prompt --application/shared_components/user_interface/lovs/lista_cantones
begin
--   Manifest
--     LISTA_CANTONES
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(34251543070233303)
,p_lov_name=>'LISTA_CANTONES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion,id from CANTONES@consulta_ictx',
'--select descripcion, id from CANTONES@consulta_ictx WHERE prov_id = :ID_PROVINCIA'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DESCRIPCION'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
