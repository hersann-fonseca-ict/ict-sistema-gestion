prompt --application/shared_components/user_interface/lovs/lista_perfiles
begin
--   Manifest
--     LISTA_PERFILES
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(12505726437732100)
,p_lov_name=>'LISTA_PERFILES'
,p_lov_query=>'select id_perfil, UPPER(nombre_perfil) from perfiles ORDER BY nombre_perfil ASC;'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_table=>'PERFILES'
,p_return_column_name=>'ID_PERFIL'
,p_display_column_name=>'UPPER(NOMBRE_PERFIL)'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
