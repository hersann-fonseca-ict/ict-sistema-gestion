prompt --application/create_application
begin
--   Manifest
--     FLOW: 201
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'DESA_GES')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Gestion_BackEnd')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'GESTION-FRONTEND200201')
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'59D8F2B0449A84CE36E0CC7E5C76624E893B7E0B89403C4AAED02AC7BEC08B4D'
,p_bookmark_checksum_function=>'SH1'
,p_compatibility_mode=>'19.2'
,p_flow_language=>'es-cr'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_allow_feedback_yn=>'Y'
,p_date_format=>'DS'
,p_timestamp_format=>'DS'
,p_timestamp_tz_format=>'DS'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_documentation_banner=>'Application created from create application wizard 2021.07.02.'
,p_authentication=>'PLUGIN'
,p_authentication_id=>wwv_flow_api.id(36352509394894395)
,p_application_tab_set=>1
,p_logo_type=>'IT'
,p_logo=>'#APP_IMAGES#app-112-logo.png'
,p_logo_text=>unistr('Sistema de Gesti\00F3n')
,p_app_builder_icon_name=>'app-icon.svg'
,p_favicons=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<link rel="shortcut icon" href="#APP_IMAGES#indice.png">',
'<link rel="icon" sizes="16x16" href="#APP_IMAGES#indice.png">',
'<link rel="icon" sizes="32x32" href="#APP_IMAGES#indice.png">',
'<link rel="apple-touch-icon" sizes="180x180" href="#APP_IMAGES#indice.png">'))
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'Release 1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'D'
,p_rejoin_existing_sessions=>'N'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'N'
,p_substitution_string_01=>'APP_NAME'
,p_substitution_value_01=>'Gestion_FrontEnd'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241025085526'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>16
,p_ui_type_name => null
);
wwv_flow_api.component_end;
end;
/
