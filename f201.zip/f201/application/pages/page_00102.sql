prompt --application/pages/page_00102
begin
--   Manifest
--     PAGE: 00102
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>102
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Modal: Gesti\00F3n de Tipos de Declaratoria Tur\00EDstica')
,p_alias=>'MODAL-GESTION-TIPOS-DT'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Datos del Tipo de Declaraci\00F3n Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function validateText(event) {',
'  var keyCode = event.keyCode;',
'  var excludedKeys = [8, 37, 39, 46, 32];',
'',
'  if (!((keyCode >= 65 && keyCode <= 90) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'} '))
,p_step_template=>wwv_flow_api.id(36356737605894393)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241031092042'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14556476881709158)
,p_plug_name=>unistr('Datos de Tipos de Declaraci\00F3n Tur\00EDstica')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(36416259815894368)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'TIPO_DECLARATORIA'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14559396891709150)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14556476881709158)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36468943774894349)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14561244056709147)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14556476881709158)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P102_ID_TIPODT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(14561663602709147)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14556476881709158)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P102_ID_TIPODT'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14556846912709155)
,p_name=>'P102_ID_TIPODT'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14556476881709158)
,p_item_source_plug_id=>wwv_flow_api.id(14556476881709158)
,p_item_default=>'SEQ_ID_TIPODT'
,p_item_default_type=>'SEQUENCE'
,p_source=>'ID_TIPODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14557221933709152)
,p_name=>'P102_NOMBRE_TIPODT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14556476881709158)
,p_item_source_plug_id=>wwv_flow_api.id(14556476881709158)
,p_prompt=>'Nombre del Tipo de Declaratoria'
,p_source=>'NOMBRE_TIPODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>55
,p_tag_attributes=>'onKeyUp="this.value = this.value.toUpperCase()"'
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14557646621709151)
,p_name=>'P102_ESTADO_TIPODT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14556476881709158)
,p_item_source_plug_id=>wwv_flow_api.id(14556476881709158)
,p_prompt=>'Estado de la Declaratoria'
,p_source=>'ESTADO_TIPODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_ESTADOS_AC_IA'
,p_lov=>'select nombre_estado, codigo_estado from estados_tramite@consulta_ictx where codigo_estado = ''AC'' or codigo_estado = ''IA'''
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Seleccionar -'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(256764783939933130)
,p_name=>'P102_PERMITE_CT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14556476881709158)
,p_item_source_plug_id=>wwv_flow_api.id(14556476881709158)
,p_prompt=>unistr('\00BFPermite Contrato Tur\00EDstico?')
,p_source=>'PERMITE_CT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_api.id(36467781684894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APPLICATION'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(258245070656473204)
,p_name=>'P102_TIPO_OPERACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14556476881709158)
,p_item_source_plug_id=>wwv_flow_api.id(14556476881709158)
,p_prompt=>unistr('Tipo de Operaci\00F3n')
,p_source=>'TIPO_OPERACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LISTA_TIPOS_OPERACION_DT'
,p_lov=>'.'||wwv_flow_api.id(39624421094645434)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Seleccionar -'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(36468105452894349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(252051372807845757)
,p_validation_name=>'VAL_NOMBRE_TIPO_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P102_NOMBRE_TIPODT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el nombre del tipo de declaratoria tur\00EDstica')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(14557221933709152)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(251730462680721825)
,p_validation_name=>'VAL_ESTADO_TIPO_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P102_ESTADO_TIPODT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un estado'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(14557646621709151)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(14559430683709150)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(14559396891709150)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(14560268734709149)
,p_event_id=>wwv_flow_api.id(14559430683709150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(252052655057874113)
,p_name=>'VALIDATE_SOLO_LETRAS'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_NOMBRE_TIPODT'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(252053045967874120)
,p_event_id=>wwv_flow_api.id(252052655057874113)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateText(event);'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14562433693709146)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(14556476881709158)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Mantenimiento Tipos de Declaratoria Tur\00EDstica')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14562864967709146)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14562008115709147)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(14556476881709158)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Mantenimiento Tipos de Declaratoria Tur\00EDstica')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
