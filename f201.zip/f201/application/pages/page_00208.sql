prompt --application/pages/page_00208
begin
--   Manifest
--     PAGE: 00208
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>201
,p_default_id_offset=>24483371295131348
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>208
,p_user_interface_id=>wwv_flow_api.id(36491496260894337)
,p_name=>unistr('Form: Seguimiento de Contratos Tur\00EDsticos')
,p_alias=>'FORM-SEGUIMIENTO-CT'
,p_step_title=>unistr('Seguimiento de Contratos Tur\00EDsticos')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241024100431'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(40054922180692297)
,p_plug_name=>unistr('Tabla: Contratos Tur\00EDsticos')
,p_region_name=>'reporte_ct'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(36404937346894372)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	e.id_empresa,',
'	dt.id_declaratoria,',
'	ct.id_contrato,',
'	e.nombre_solicitante, ',
'	e.razon_social, ',
'	e.nombre_comercial, ',
'	e.telefono, ',
'	e.correo, ',
'	e.id_provincia, ',
'	dt.fecha_registro as "FechaDT",',
'	dt.id_analista as "AnalistaDT",',
'	dt.fecha_asig_analista as "FAnalistaDT",',
'	dt.id_inspector as "InspectorDT",',
'	dt.fecha_asig_inspector as "FInspectorDT", ',
'	dt.estadodt,',
'	ct.fecha_registro,',
'	ct.id_analista,',
'	ct.fecha_asig_analista,',
'	ct.id_inspector,',
'	ct.fecha_asig_inspector,',
'	ct.estadoct',
'FROM empresa e',
'	INNER JOIN declaratoria_turistica dt ON e.id_empresa = dt.id_empresa',
'	INNER JOIN contrato_turistico ct ON ct.id_declaratoria = dt.id_declaratoria',
'ORDER BY ct.id_contrato DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Tabla: Contratos Tur\00EDsticos')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(39641157029928516)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No se encontraron datos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>39641157029928516
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313270968594509)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'EX'
,p_column_label=>'Ver detalles'
,p_column_link=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.::P207_ID_EMPRESA,P207_ID_DECLARATORIA,P207_ID_CONTRATO:#ID_EMPRESA#,#ID_DECLARATORIA#,#ID_CONTRATO#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-window-search"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313367399594510)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>20
,p_column_identifier=>'EY'
,p_column_label=>'ID Declaratoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313426363594511)
,p_db_column_name=>'ID_CONTRATO'
,p_display_order=>30
,p_column_identifier=>'EZ'
,p_column_label=>'ID Contrato'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313560648594512)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'FA'
,p_column_label=>'Nombre del Solicitante'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313633609594513)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>50
,p_column_identifier=>'FB'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313770149594514)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>60
,p_column_identifier=>'FC'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313857032594515)
,p_db_column_name=>'TELEFONO'
,p_display_order=>70
,p_column_identifier=>'FD'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251313935182594516)
,p_db_column_name=>'CORREO'
,p_display_order=>80
,p_column_identifier=>'FE'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314064970594517)
,p_db_column_name=>'ID_PROVINCIA'
,p_display_order=>90
,p_column_identifier=>'FF'
,p_column_label=>'Provincia'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(19980461641459915)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314167148594518)
,p_db_column_name=>'FechaDT'
,p_display_order=>100
,p_column_identifier=>'FG'
,p_column_label=>'Fechadt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314278408594519)
,p_db_column_name=>'AnalistaDT'
,p_display_order=>110
,p_column_identifier=>'FH'
,p_column_label=>'Analistadt'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314306092594520)
,p_db_column_name=>'FAnalistaDT'
,p_display_order=>120
,p_column_identifier=>'FI'
,p_column_label=>'Fanalistadt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314407760594521)
,p_db_column_name=>'InspectorDT'
,p_display_order=>130
,p_column_identifier=>'FJ'
,p_column_label=>'Inspectordt'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314560046594522)
,p_db_column_name=>'FInspectorDT'
,p_display_order=>140
,p_column_identifier=>'FK'
,p_column_label=>'Finspectordt'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314611614594523)
,p_db_column_name=>'ESTADODT'
,p_display_order=>150
,p_column_identifier=>'FL'
,p_column_label=>'Estadodt'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314777449594524)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>160
,p_column_identifier=>'FM'
,p_column_label=>'Fecha de Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314825303594525)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>170
,p_column_identifier=>'FN'
,p_column_label=>'Analista Asignado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(38604833692717378)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251314968909594526)
,p_db_column_name=>'FECHA_ASIG_ANALISTA'
,p_display_order=>180
,p_column_identifier=>'FO'
,p_column_label=>'Fecha Asig Analista'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251315000234594527)
,p_db_column_name=>'ID_INSPECTOR'
,p_display_order=>190
,p_column_identifier=>'FP'
,p_column_label=>'Inspector Asignado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(38604833692717378)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251315140158594528)
,p_db_column_name=>'FECHA_ASIG_INSPECTOR'
,p_display_order=>200
,p_column_identifier=>'FQ'
,p_column_label=>'Fecha Asig Inspector'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(251315240231594529)
,p_db_column_name=>'ESTADOCT'
,p_display_order=>210
,p_column_identifier=>'FR'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(161672685883171523)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(40090644345763379)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'400907'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FFID_CLAVE:ID_EMPRESA:ID_DECLARATORIA:ID_CONTRATO:NOMBRE_SOLICITANTE:RAZON_SOCIAL:NOMBRE_COMERCIAL:TELEFONO:CORREO:ID_PROVINCIA:FechaDT:AnalistaDT:FAnalistaDT:InspectorDT:FInspectorDT:ESTADODT:FECHA_REGISTRO:ID_ANALISTA:FECHA_ASIG_ANALISTA:ID_INSPECT'
||'OR:FECHA_ASIG_INSPECTOR:ESTADOCT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(2986303563718432697)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(36406847262894371)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Seguimiento de Contratos Tur\00EDsticos</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(251454118397587468)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(40054922180692297)
,p_button_name=>'BTN_REFRESCAR_TABLA_CT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconLeft:t-Button--hoverIconSpin:t-Button--padRight:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_api.id(36469031726894349)
,p_button_image_alt=>'Refrescar'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40064482184692317)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(40054922180692297)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40064919999692318)
,p_event_id=>wwv_flow_api.id(40064482184692317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(40054922180692297)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(251454396642590198)
,p_name=>'DAC_REFRESCAR_TABLA_DT'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(251454118397587468)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(251454716098590208)
,p_event_id=>wwv_flow_api.id(251454396642590198)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("reporte_ct").refresh();'
);
wwv_flow_api.component_end;
end;
/
